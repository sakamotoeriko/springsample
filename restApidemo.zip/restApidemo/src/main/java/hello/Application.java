package hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;*/

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
    	//Document doc = Jsoup.connect("http//en.wikipedia.org/").get();
    	//Elements newsHeadlines = doc.select("#mp-itn b a");
        SpringApplication.run(Application.class, args);
    }

}